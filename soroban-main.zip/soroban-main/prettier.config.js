module.exports = {
    trailingComma: 'all',
    tabWidth: 4,
    singleQuote: true,
    arrowParens: 'avoid',
};
